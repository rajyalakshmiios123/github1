

let MoviesURL:String = "http://api.themoviedb.org/3/discover/movie?api_key=ab41356b33d100ec61e6c098ecc92140&sort_by=popularity.desc"
