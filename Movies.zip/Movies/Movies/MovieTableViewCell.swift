

import UIKit

class MovieTableViewCell: UITableViewCell {

    @IBOutlet var titleLabels: [UILabel] = []
    
    @IBOutlet var descriptionLabels: [UILabel] = []
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        setUpCell()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func setUpCell(){
        
        for label in titleLabels{
            label.font = UIFont(name: "Helvetica-Bold", size: 16.0)
            label.textAlignment = .left
            label.textColor = UIColor.black
        }
        
        
        for label in descriptionLabels{
            label.font = UIFont(name: "Helvetica", size: 14.0)
            label.textAlignment = .left
            label.textColor = UIColor.blue
        }
        
    }
    
    func configureCell(withModel:MovieModel) {
        
        descriptionLabels[1].text = withModel.title
        descriptionLabels[0].text = String(withModel.voteAverage)
     
        
        
    }
    
    static func preferedHeight()->CGFloat{
        return 71.0
    }
    
}
