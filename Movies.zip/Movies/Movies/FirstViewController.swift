import UIKit

class FirstViewController: UIViewController, UITableViewDelegate,UITableViewDataSource {

    @IBOutlet var networkIndicator: UIActivityIndicatorView!
    @IBOutlet weak var moviesTable: UITableView!
    @IBOutlet var emptyListLabel: UILabel!
    var moviesList : [MovieModel] = []
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
   //This method makes the URLRequest to get data from endpoint
        requestMoviesData()
        
        setUpTable()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
   
    }

    // MARK: TableView DataSource
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int{
        
        return moviesList.count
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell{
        
        let cell : MovieTableViewCell = moviesTable.dequeueReusableCell(withIdentifier: "MovieTableViewCell") as! MovieTableViewCell
        cell.configureCell(withModel: moviesList[indexPath.row])
        cell.selectionStyle = .none
        return cell
    }
    
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat{
        return MovieTableViewCell.preferedHeight()
    }
    
    // MARK: TableView Delegate
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath){
        
        let controller : DetailMovieViewController = DetailMovieViewController(nibName: "DetailMovieViewController", bundle: nil)
        controller.selectedMovie = moviesList[indexPath.row]
        self.addChildViewController(controller)
        self.view.addSubview(controller.view)
        controller.didMove(toParentViewController: self)
    }

    // MARK: UI methods
   func setUpTable(){
    moviesTable.delegate = self
    moviesTable.dataSource = self
    moviesTable.backgroundColor = UIColor.clear
    moviesTable.register(UINib(nibName: "MovieTableViewCell", bundle: nil), forCellReuseIdentifier: "MovieTableViewCell")
    }
// MARK: Service call
    func requestMoviesData(){
       
        
        // Create NSURL Ibject
        let myUrl = URL(string: MoviesURL);
        
        // Creaste URL Request
        let request = NSMutableURLRequest(url:myUrl!);
        
        // Set request HTTP method to GET. It could be POST as well
        request.httpMethod = "POST"
        
        networkIndicator.startAnimating()
        

        let task = URLSession.shared.dataTask(with: request as URLRequest) {
            data, response, error in
            
            // Checking for error
            if error != nil
            {
                 self.networkIndicator.stopAnimating()
                let alertController = UIAlertController(title: "Sorry", message: "Unable to retrieve data", preferredStyle: .alert)
                
                let OkAction = UIAlertAction(title: "OK", style: .default) { action in
                 
                }
                alertController.addAction(OkAction)
                
                self.present(alertController, animated: true) {
                self.moviesTable.isHidden = true
                self.emptyListLabel.isHidden = false
                }
         
                return
            }
            
            // Convert server json response to NSDictionary
            do {
                 self.networkIndicator.stopAnimating()
                if let convertedJsonIntoDict = try JSONSerialization.jsonObject(with: data!, options: []) as? [String : Any] {
                    if let results: [[String : Any]] = convertedJsonIntoDict["results"] as? [[String : Any]]{
                       
                        //Parsing data into models
                        for movieDic in results{
                            let movie = MovieModel(dictionary: movieDic)
                            self.moviesList.append(movie)
                        }
                    }
                    
                }
                
                DispatchQueue.main.async { [unowned self] in
                    self.moviesTable.reloadData()
                }
            } catch let error as NSError {
                print(error.localizedDescription)
                let alertController = UIAlertController(title: "Sorry", message: "Unable to retrieve data", preferredStyle: .alert)
                
                let OkAction = UIAlertAction(title: "OK", style: .default) { action in
                    
                }
                alertController.addAction(OkAction)
                
                self.present(alertController, animated: true) {
                    self.moviesTable.isHidden = true
                    self.emptyListLabel.isHidden = false
                }

            }

            }
            task.resume()
    }
}

