

import UIKit

class SecondViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {

    public static var favorites : [MovieModel] = []
    @IBOutlet weak var moviesTable: UITableView!
    
    @IBOutlet var noFavoritesLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        setUpTable()
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        if SecondViewController.favorites.count == 0{
            noFavoritesLabel.isHidden = false
            moviesTable.isHidden = true
        }
        else{
            noFavoritesLabel.isHidden = true
            moviesTable.isHidden = false
        }
        self.moviesTable.reloadData()
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: TableView DataSource
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int{
        
        return SecondViewController.favorites.count
        
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell{
        
        let cell : MovieTableViewCell = moviesTable.dequeueReusableCell(withIdentifier: "MovieTableViewCell") as! MovieTableViewCell
        cell.configureCell(withModel: SecondViewController.favorites[indexPath.row])
        return cell
    }
    
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat{
        return MovieTableViewCell.preferedHeight()
    }
    
    // MARK: TableView Delegate
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath){
        
        let controller : DetailMovieViewController = DetailMovieViewController(nibName: "DetailMovieViewController", bundle: nil)
        controller.selectedMovie = SecondViewController.favorites[indexPath.row]
        view.addSubview(controller.view)
    }


   
    // MARK: UI methods
    func setUpTable(){
        moviesTable.delegate = self
        moviesTable.dataSource = self
        moviesTable.backgroundColor = UIColor.clear
        moviesTable.register(UINib(nibName: "MovieTableViewCell", bundle: nil), forCellReuseIdentifier: "MovieTableViewCell")
    }
}

