
import UIKit

class MovieModel: NSObject {
    var overview:String
    var releaseDate: String
    var uniqueId:Int
    var title: String
    var voteAverage:Float
    
    init(dictionary : [String : Any]){
        overview = dictionary["overview"] as! String
        releaseDate = dictionary["release_date"] as! String
        uniqueId = dictionary["id"] as! Int
        title = dictionary["original_title"] as! String? ?? dictionary["original_title"] as! String
        voteAverage = dictionary["vote_average"] as! Float
        
    }
    
}
