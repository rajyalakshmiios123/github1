
import UIKit

class DetailMovieViewController: UIViewController {

 
    @IBOutlet var favButton: UIButton!
    @IBOutlet var backButton: UIButton!
    @IBOutlet var descriptionLabels: [UILabel] = []
    @IBOutlet var titleLabels: [UILabel] = []
    @IBOutlet var movieDescriptionLabel: UILabel!
    var selectedMovie : MovieModel?
    
    override func viewDidLoad() {
   
        super.viewDidLoad()
        view.becomeFirstResponder()
        setUp()
        configure()
    }

    func addFavourite() {
        SecondViewController.favorites.append(selectedMovie!)
        let alertController = UIAlertController(title: "Successfully added to favorites!", message: "", preferredStyle: .alert)
        
        let OkAction = UIAlertAction(title: "OK", style: .default) { action in
            self.view.removeFromSuperview()
        }
        alertController.addAction(OkAction)
        
        self.present(alertController, animated: true) {
           
        }

    }
    func backIT() {
        
        view.removeFromSuperview()
    }
    
           override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    func setUp(){
        
        for label in titleLabels{
            label.font = UIFont(name: "Helvetica-Bold", size: 16.0)
            label.textAlignment = .left
            label.textColor = UIColor.black
        }
        
        
        for label in descriptionLabels{
            label.font = UIFont(name: "Helvetica", size: 14.0)
            label.textAlignment = .left
            label.textColor = UIColor.black
        }
        
        movieDescriptionLabel.font = UIFont(name: "Helvetica-Bold", size: 14.0)
        movieDescriptionLabel.textAlignment = .left
        movieDescriptionLabel.textColor = UIColor.black
        view.backgroundColor = UIColor.lightGray
        favButton.addTarget(self, action: #selector(DetailMovieViewController.addFavourite), for: UIControlEvents.touchUpInside)
        backButton.setTitle("Back", for: UIControlState.normal)
        backButton.addTarget(self, action: #selector(DetailMovieViewController.backIT), for: UIControlEvents.touchUpInside)
    }

    func configure() {
        
        descriptionLabels[0].text = selectedMovie?.title
        descriptionLabels[1].text = String(describing: selectedMovie!.voteAverage)
        descriptionLabels[2].text = selectedMovie?.releaseDate
        movieDescriptionLabel.text = selectedMovie?.overview
        
        
    }


}
