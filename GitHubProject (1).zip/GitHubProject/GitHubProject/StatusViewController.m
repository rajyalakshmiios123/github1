//
//  StatusViewController.m
//  GitHubProject
//
//  Created by Ankam Mounika on 4/6/17.
//  Copyright © 2017 Mounika. All rights reserved.
//

#import "StatusViewController.h"
#import "LoginViewController.h"

@interface StatusViewController ()

@end

@implementation StatusViewController

- (IBAction)goBackToLoginScreen:(id)sender {
    
}


@end
